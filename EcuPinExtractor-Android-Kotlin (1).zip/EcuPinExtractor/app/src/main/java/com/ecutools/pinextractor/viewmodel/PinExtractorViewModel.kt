package com.ecutools.pinextractor.viewmodel

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.ecutools.pinextractor.engine.PinExtractorEngine
import com.ecutools.pinextractor.model.EcuType
import com.ecutools.pinextractor.model.ExtractionResult
import com.ecutools.pinextractor.model.ExtractionStatus
import com.ecutools.pinextractor.model.LoadedFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class UiState(
    val selectedEcu: EcuType = EcuType.AUTO_DETECT,
    val loadedFile: LoadedFile? = null,
    val extractionResult: ExtractionResult? = null,
    val isLoading: Boolean = false,
    val userNotice: String? = null
)

class PinExtractorViewModel(
    private val engine: PinExtractorEngine = PinExtractorEngine()
) : ViewModel() {

    private val _uiState = MutableStateFlow(UiState())
    val uiState: StateFlow<UiState> = _uiState.asStateFlow()

    init {
        // Pre-load default sample for discovery
        loadSampleDump(EcuType.SAGEM_VALEO_S2000)
    }

    /**
     * Changes ECU scan profile and triggers re-parsing if file is loaded.
     */
    fun selectEcuType(ecuType: EcuType) {
        _uiState.update { it.copy(selectedEcu = ecuType) }
        val currentFile = _uiState.value.loadedFile
        if (currentFile != null) {
            parseCurrentFile(currentFile.bytes, ecuType)
        }
    }

    /**
     * Reads file from Android Storage Access Framework (SAF) URI.
     * Guaranteed 100% offline local memory stream.
     */
    fun loadFileFromUri(uri: Uri, context: Context) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, userNotice = null) }

            try {
                val (fileName, fileBytes) = withContext(Dispatchers.IO) {
                    var name = "eeprom_dump.bin"
                    context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                        val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        if (nameIndex != -1 && cursor.moveToFirst()) {
                            name = cursor.getString(nameIndex) ?: name
                        }
                    }

                    val inputStream = context.contentResolver.openInputStream(uri)
                        ?: throw IllegalArgumentException("Cannot open stream for selected file.")

                    val bytes = inputStream.use { it.readBytes() }
                    Pair(name, bytes)
                }

                // File validation checks
                if (fileBytes.isEmpty()) {
                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            extractionResult = ExtractionResult(
                                status = ExtractionStatus.STATUS_UNSUPPORTED_DUMP,
                                errorMessage = "Selected file '$fileName' is empty (0 bytes)."
                            )
                        )
                    }
                    return@launch
                }

                if (fileBytes.size > 2 * 1024 * 1024) {
                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            extractionResult = ExtractionResult(
                                status = ExtractionStatus.STATUS_UNSUPPORTED_DUMP,
                                errorMessage = "File exceeds 2MB safety threshold (${fileBytes.size / 1024} KB). EEPROMs are typically 128B - 64KB."
                            )
                        )
                    }
                    return@launch
                }

                val loadedFile = LoadedFile(
                    name = fileName,
                    sizeBytes = fileBytes.size.toLong(),
                    bytes = fileBytes
                )

                _uiState.update { it.copy(loadedFile = loadedFile, isLoading = false) }
                parseCurrentFile(fileBytes, _uiState.value.selectedEcu)

            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        extractionResult = ExtractionResult(
                            status = ExtractionStatus.STATUS_UNSUPPORTED_DUMP,
                            errorMessage = "Error reading binary file: ${e.localizedMessage ?: "Unknown error"}"
                        )
                    )
                }
            }
        }
    }

    /**
     * Loads built-in realistic EEPROM dump for direct testing.
     */
    fun loadSampleDump(type: EcuType) {
        val (sampleName, sampleBytes) = when (type) {
            EcuType.SAGEM_VALEO_S2000 -> Pair(
                "sagem_s2000_95080_peugeot.bin",
                engine.createSampleSagemS2000Dump()
            )
            EcuType.SIEMENS_VDO_CROUSE -> Pair(
                "siemens_crouse_cge_95160.bin",
                engine.createSampleSiemensCrouseDump()
            )
            EcuType.VALEO_J34P_PL4 -> Pair(
                "valeo_j34p_95160_tu3a.bin",
                engine.createSampleValeoJ34PDump()
            )
            EcuType.FIAT_BOSCH_MARELLI -> Pair(
                "fiat_marelli_95160_5digit.bin",
                engine.createSampleFiatMarelliDump()
            )
            EcuType.DELPHI_MT20U_MT22U -> Pair(
                "delphi_mt20u_24c02_chery.bin",
                engine.createSampleDelphiChineseDump()
            )
            else -> Pair(
                "sagem_s2000_95080_peugeot.bin",
                engine.createSampleSagemS2000Dump()
            )
        }

        val loadedFile = LoadedFile(
            name = sampleName,
            sizeBytes = sampleBytes.size.toLong(),
            bytes = sampleBytes
        )

        _uiState.update {
            it.copy(
                selectedEcu = type,
                loadedFile = loadedFile,
                userNotice = "Loaded verified sample: $sampleName"
            )
        }

        parseCurrentFile(sampleBytes, type)
    }

    /**
     * Loads an unprogrammed / virgin dump to test Virgin & Immo-off detection.
     */
    fun loadVirginSample() {
        val sampleName = "virgin_immo_off_dump.bin"
        val sampleBytes = engine.createSampleVirginDump()

        val loadedFile = LoadedFile(
            name = sampleName,
            sizeBytes = sampleBytes.size.toLong(),
            bytes = sampleBytes
        )

        _uiState.update {
            it.copy(
                selectedEcu = EcuType.AUTO_DETECT,
                loadedFile = loadedFile,
                userNotice = "Loaded Virgin / Immo-Off EEPROM dump"
            )
        }

        parseCurrentFile(sampleBytes, EcuType.AUTO_DETECT)
    }

    /**
     * Runs parsing engine on the current byte array.
     */
    private fun parseCurrentFile(bytes: ByteArray, ecuType: EcuType) {
        val result = engine.extractPin(bytes, ecuType)
        _uiState.update { it.copy(extractionResult = result) }
    }

    /**
     * Copies extracted PIN code to Android system clipboard.
     */
    fun copyPinToClipboard(context: Context, pin: String) {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText("ECU PIN Code", pin)
        clipboard.setPrimaryClip(clip)
        _uiState.update { it.copy(userNotice = "PIN '$pin' copied to clipboard") }
    }

    fun dismissNotice() {
        _uiState.update { it.copy(userNotice = null) }
    }
}
