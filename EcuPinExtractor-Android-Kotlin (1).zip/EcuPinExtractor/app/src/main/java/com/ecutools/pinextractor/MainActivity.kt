package com.ecutools.pinextractor

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import com.ecutools.pinextractor.ui.PinExtractorScreen
import com.ecutools.pinextractor.ui.theme.EcuPinExtractorTheme
import com.ecutools.pinextractor.viewmodel.PinExtractorViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: PinExtractorViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            EcuPinExtractorTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color(0xFF0B0F19)
                ) {
                    PinExtractorScreen(viewModel = viewModel)
                }
            }
        }
    }
}
