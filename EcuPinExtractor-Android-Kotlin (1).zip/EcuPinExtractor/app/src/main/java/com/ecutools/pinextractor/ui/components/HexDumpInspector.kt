package com.ecutools.pinextractor.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ecutools.pinextractor.model.HexLine

/**
 * Clean 16-byte Hex Dump Inspector.
 * Displays memory offset, 16 hex byte columns, and printable ASCII column.
 * Target PIN bytes (4 or 5 bytes) are highlighted with amber border & background.
 */
@Composable
fun HexDumpInspector(
    hexLines: List<HexLine>,
    targetOffsetHex: String?,
    targetLength: Int = 4,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFF0F172A))
            .border(1.dp, Color(0xFF334155), RoundedCornerShape(12.dp))
            .padding(12.dp)
    ) {
        // Inspector Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "HEX DUMP INSPECTOR (16-BYTE ALIGNED)",
                color = Color(0xFF94A3B8),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
            if (targetOffsetHex != null) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "Target: $targetOffsetHex",
                        color = Color(0xFFF59E0B),
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "($targetLength Bytes)",
                        color = Color(0xFF38BDF8),
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Horizontal scroll container for narrow phone screens
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(scrollState)
        ) {
            Column(
                modifier = Modifier.padding(vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                // Table Column Labels
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(bottom = 2.dp)
                ) {
                    Text(
                        text = "Offset",
                        color = Color(0xFF64748B),
                        fontFamily = FontFamily.Monospace,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.width(64.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = "00 01 02 03 04 05 06 07  08 09 0A 0B 0C 0D 0E 0F",
                        color = Color(0xFF64748B),
                        fontFamily = FontFamily.Monospace,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.width(360.dp)
                    )
                    Spacer(modifier = Modifier.width(16.dp))
                    Text(
                        text = "ASCII (Decoded)",
                        color = Color(0xFF64748B),
                        fontFamily = FontFamily.Monospace,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                if (hexLines.isEmpty()) {
                    Text(
                        text = "No byte data to display. Load an EEPROM dump file.",
                        color = Color(0xFF64748B),
                        fontSize = 12.sp,
                        modifier = Modifier.padding(vertical = 12.dp)
                    )
                } else {
                    hexLines.forEach { line ->
                        HexRowItem(line = line)
                    }
                }
            }
        }
    }
}

@Composable
private fun HexRowItem(line: HexLine) {
    val rowBackground = if (line.isTargetLine) Color(0xFF1E293B) else Color.Transparent
    val rowBorder = if (line.isTargetLine) Color(0xFFF59E0B).copy(alpha = 0.4f) else Color.Transparent

    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(rowBackground)
            .border(1.dp, rowBorder, RoundedCornerShape(4.dp))
            .padding(horizontal = 4.dp, vertical = 2.dp)
    ) {
        // Offset Column
        Text(
            text = line.offsetHex,
            color = if (line.isTargetLine) Color(0xFFF59E0B) else Color(0xFF38BDF8),
            fontFamily = FontFamily.Monospace,
            fontSize = 12.sp,
            fontWeight = if (line.isTargetLine) FontWeight.Bold else FontWeight.Normal,
            modifier = Modifier.width(60.dp)
        )

        Spacer(modifier = Modifier.width(12.dp))

        // Hex Byte Values (16 bytes split with space in middle)
        Row(modifier = Modifier.width(360.dp)) {
            line.hexValues.forEachIndexed { index, hexVal ->
                val isTargetByte = line.targetByteIndices.contains(index)
                val byteBg = if (isTargetByte) Color(0xFFF59E0B).copy(alpha = 0.25f) else Color.Transparent
                val byteColor = if (isTargetByte) Color(0xFFFDE047) else Color(0xFFE2E8F0)

                Box(
                    modifier = Modifier
                        .padding(horizontal = 1.dp)
                        .clip(RoundedCornerShape(2.dp))
                        .background(byteBg)
                        .padding(horizontal = 2.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = hexVal,
                        color = byteColor,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 12.sp,
                        fontWeight = if (isTargetByte) FontWeight.ExtraBold else FontWeight.Normal
                    )
                }

                if (index == 7) {
                    Spacer(modifier = Modifier.width(6.dp))
                }
            }
        }

        Spacer(modifier = Modifier.width(16.dp))

        // ASCII Column
        Text(
            text = line.asciiRepresentation,
            color = if (line.isTargetLine) Color(0xFFFBBF24) else Color(0xFF94A3B8),
            fontFamily = FontFamily.Monospace,
            fontSize = 12.sp,
            fontWeight = if (line.isTargetLine) FontWeight.Bold else FontWeight.Normal
        )
    }
}
