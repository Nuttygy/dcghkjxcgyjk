package com.ecutools.pinextractor.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val AmberAccent = Color(0xFFF59E0B)
val AmberGlow = Color(0xFFD97706)
val CyanAccent = Color(0xFF06B6D4)
val EmeraldSuccess = Color(0xFF10B981)
val DarkNavy900 = Color(0xFF0B0F19)
val DarkNavy800 = Color(0xFF111827)
val DarkNavy700 = Color(0xFF1F2937)
val BorderSlate700 = Color(0xFF374151)

private val DarkColorScheme = darkColorScheme(
    primary = AmberAccent,
    secondary = CyanAccent,
    tertiary = EmeraldSuccess,
    background = DarkNavy900,
    surface = DarkNavy800,
    surfaceVariant = DarkNavy700,
    onPrimary = Color.Black,
    onSecondary = Color.Black,
    onBackground = Color(0xFFF3F4F6),
    onSurface = Color(0xFFF3F4F6)
)

private val LightColorScheme = lightColorScheme(
    primary = AmberGlow,
    secondary = CyanAccent,
    tertiary = EmeraldSuccess,
    background = Color(0xFFF8FAFC),
    surface = Color.White,
    surfaceVariant = Color(0xFFE2E8F0),
    onPrimary = Color.White,
    onSecondary = Color.Black,
    onBackground = Color(0xFF0F172A),
    onSurface = Color(0xFF0F172A)
)

@Composable
fun EcuPinExtractorTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        content = content
    )
}
