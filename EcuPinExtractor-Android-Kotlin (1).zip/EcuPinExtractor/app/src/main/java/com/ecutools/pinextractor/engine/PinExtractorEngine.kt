package com.ecutools.pinextractor.engine

import com.ecutools.pinextractor.model.CandidatePin
import com.ecutools.pinextractor.model.EcuType
import com.ecutools.pinextractor.model.ExtractionResult
import com.ecutools.pinextractor.model.ExtractionStatus
import com.ecutools.pinextractor.model.HexLine

/**
 * 100% Offline Core Engine for extracting Immobilizer PIN codes
 * from automotive EEPROM dumps (ST95080, ST95160, ST95320, 24C02, 93C46, 93C66).
 *
 * Specially calibrated for Iranian (IKCO, Saipa), Chinese (Chery, Lifan, Geely, MVM, JAC),
 * and European (PSA, Fiat, Renault, Bosch) ECUs & BSI modules.
 */
class PinExtractorEngine {

    companion object {
        private val PIN_4CHAR_REGEX = Regex("^[A-Z0-9]{4}$")
        private val PIN_5DIGIT_REGEX = Regex("^[0-9]{5}$")

        private val FILLER_4CHAR = setOf(
            "FFFF", "0000", "9999", "1111", "AAAA", "5555", "3333", "7777",
            "XXXX", "ZZZZ", "....", "----", "2222", "8888"
        )

        private val FILLER_5DIGIT = setOf(
            "00000", "11111", "99999", "55555", "77777", "33333"
        )
    }

    /**
     * Extracts PIN code based on selected ECU type or Auto-Detect mode.
     */
    fun extractPin(bytes: ByteArray, ecuType: EcuType): ExtractionResult {
        if (bytes.isEmpty()) {
            return ExtractionResult(
                status = ExtractionStatus.STATUS_UNSUPPORTED_DUMP,
                errorMessage = "Dump file is empty (0 bytes). Please supply a valid EEPROM binary dump."
            )
        }

        if (bytes.size > 2 * 1024 * 1024) {
            return ExtractionResult(
                status = ExtractionStatus.STATUS_UNSUPPORTED_DUMP,
                errorMessage = "File size (${bytes.size / 1024} KB) exceeds 2MB limit. EEPROMs are typically 128B to 64KB."
            )
        }

        return when (ecuType) {
            EcuType.SAGEM_VALEO_S2000 -> extractSagemS2000(bytes)
            EcuType.SIEMENS_VDO_CROUSE -> extractSiemensVdoCrouse(bytes)
            EcuType.VALEO_J34P_PL4 -> extractValeoJ34P(bytes)
            EcuType.BOSCH_M797_ME744 -> extractBoschM797ME744(bytes)
            EcuType.BOSCH_ME17971 -> extractBoschME17971(bytes)
            EcuType.PEUGEOT_206_207_BSI -> extractPeugeotBsi(bytes)
            EcuType.CITROEN_XANTIA_CPH -> extractXantiaCph(bytes)
            EcuType.DELPHI_MT20U_MT22U -> extractDelphiMt20u(bytes)
            EcuType.FIAT_BOSCH_MARELLI -> extractFiatMarelli(bytes)
            EcuType.AUTO_DETECT -> autoDetect(bytes)
        }
    }

    /**
     * Sagem / Valeo S2000 (EEPROM 95080)
     * - Primary: 0x0100..0x0103, Mirror: 0x0110..0x0113
     * - Format: 4-char ASCII (Standard & Byte-Swapped / Reversed)
     */
    fun extractSagemS2000(bytes: ByteArray): ExtractionResult {
        val offsets = listOf(0x0100, 0x0110)
        return checkOffsets4Char(
            bytes = bytes,
            offsets = offsets,
            ecuName = "Sagem / Valeo S2000 (EEPROM 95080)",
            allowByteSwap = true
        )
    }

    /**
     * Siemens VDO / Crouse / CGE / SSAT (EEPROM 95080/95160)
     * - Offsets: 0x03F0..0x03F3, 0x00A0..0x00A3, 0x01F0..0x01F3
     * - Format: 4-char Alphanumeric ASCII
     */
    fun extractSiemensVdoCrouse(bytes: ByteArray): ExtractionResult {
        val offsets = listOf(0x03F0, 0x00A0, 0x01F0)
        return checkOffsets4Char(
            bytes = bytes,
            offsets = offsets,
            ecuName = "Siemens VDO / Crouse / CGE / SSAT",
            allowByteSwap = true
        )
    }

    /**
     * Valeo J34P / J35 / PL4 (EEPROM 95160/95320 - Peugeot 206+ TU3A/TU5)
     * - Offsets: 0x00A0..0x00A3, 0x0320..0x0323
     * - Format: 4-char Alphanumeric ASCII
     */
    fun extractValeoJ34P(bytes: ByteArray): ExtractionResult {
        val offsets = listOf(0x00A0, 0x0320)
        return checkOffsets4Char(
            bytes = bytes,
            offsets = offsets,
            ecuName = "Valeo J34P / J35 / PL4",
            allowByteSwap = true
        )
    }

    /**
     * Bosch M7.9.7 / M7.9.71 / ME7.4.4 / ME7.4.5 (EEPROM 95080/95160 - Pride, Samand, 206)
     * - Offsets: 0x01E0..0x01E3, 0x0030..0x0033
     * - Format: 4-digit Numeric ASCII or Alphanumeric
     */
    fun extractBoschM797ME744(bytes: ByteArray): ExtractionResult {
        val offsets = listOf(0x01E0, 0x0030)
        return checkOffsets4Char(
            bytes = bytes,
            offsets = offsets,
            ecuName = "Bosch M7.9.7 / ME7.4.4 / ME7.4.5",
            allowByteSwap = true
        )
    }

    /**
     * Bosch ME17.9.71 (TU5 / EF7 Tricore EEPROM Emulation)
     * - Offsets: 0x01F0..0x01F3, 0x0280..0x0283
     * - Format: 4-char PIN
     */
    fun extractBoschME17971(bytes: ByteArray): ExtractionResult {
        val offsets = listOf(0x01F0, 0x0280)
        return checkOffsets4Char(
            bytes = bytes,
            offsets = offsets,
            ecuName = "Bosch ME17.9.71 (Tricore)",
            allowByteSwap = true
        )
    }

    /**
     * Peugeot 206 / 207 BSI (Johnson Controls / Valeo / Siemens - 95160 / 95040 / NEC)
     * - Offsets: 0x0040..0x0043, 0x02E0..0x02E3, 0x0520..0x0523
     * - Format: 4-char ASCII (Straight & Inverted order)
     */
    fun extractPeugeotBsi(bytes: ByteArray): ExtractionResult {
        val offsets = listOf(0x0040, 0x02E0, 0x0520)
        return checkOffsets4Char(
            bytes = bytes,
            offsets = offsets,
            ecuName = "Peugeot 206 / 207 BSI",
            allowByteSwap = true
        )
    }

    /**
     * Citroen Xantia CPH (EEPROM 93C46 / 95040 Texton Immobilizer)
     * - Offsets: 0x0008..0x000B, 0x0010..0x0013
     * - Format: 4-char ASCII
     */
    fun extractXantiaCph(bytes: ByteArray): ExtractionResult {
        val offsets = listOf(0x0008, 0x0010)
        return checkOffsets4Char(
            bytes = bytes,
            offsets = offsets,
            ecuName = "Citroen Xantia CPH Texton",
            allowByteSwap = true
        )
    }

    /**
     * Delphi MT20U / MT22U / MT38 / MT80 (Chinese vehicles: Chery, Lifan, Geely, JAC, MVM)
     * - Offsets: 0x0060..0x0063, 0x01A0..0x01A3
     * - Format: 4-digit numeric or alphanumeric ASCII
     */
    fun extractDelphiMt20u(bytes: ByteArray): ExtractionResult {
        val offsets = listOf(0x0060, 0x01A0)
        return checkOffsets4Char(
            bytes = bytes,
            offsets = offsets,
            ecuName = "Delphi MT20U / MT22U / MT38 (Chinese)",
            allowByteSwap = true
        )
    }

    /**
     * Fiat Bosch / Magneti Marelli (EEPROM 95080/95160 - Linea, Palio, Punto, Bravo)
     * - Offsets: 0x026F..0x0273 or 0x01E0..0x01E4
     * - Format: EXACT 5-digit numeric ASCII string ([0-9]{5})
     */
    fun extractFiatMarelli(bytes: ByteArray): ExtractionResult {
        val offsets = listOf(0x026F, 0x01E0)

        // 1. Check for Virgin / Immo-Off in primary offset
        for (offset in offsets) {
            if (offset + 5 <= bytes.size) {
                val slice = bytes.copyOfRange(offset, offset + 5)
                if (isVirginOrImmoOffBytes(slice)) {
                    val hexLines = generateHexInspector(bytes, offset, 5)
                    return ExtractionResult(
                        status = ExtractionStatus.STATUS_VIRGIN_OR_IMMO_OFF,
                        pinLength = 5,
                        targetOffset = offset,
                        targetOffsetHex = "0x%04X".format(offset),
                        rawHex = sliceToHex(slice),
                        detectedEcu = "Fiat Bosch / Magneti Marelli",
                        algorithmDetails = "Target offset 0x%04X has virgin/immo-off bytes (0xFF/0x00)".format(offset),
                        errorMessage = "DUMP IS VIRGIN / IMMO-OFF (NO PIN REQUIRED)",
                        hexLines = hexLines
                    )
                }

                // Check 5-digit numeric ASCII
                val ascii = bytesToAscii(slice)
                val rawHex = sliceToHex(slice)
                if (isValid5DigitPin(ascii)) {
                    val hexLines = generateHexInspector(bytes, offset, 5)
                    return ExtractionResult(
                        status = ExtractionStatus.VALID_PIN_FOUND,
                        pin = ascii,
                        pinLength = 5,
                        targetOffset = offset,
                        targetOffsetHex = "0x%04X".format(offset),
                        rawHex = rawHex,
                        isByteSwapped = false,
                        detectedEcu = "Fiat Bosch / Magneti Marelli (5-Digit)",
                        algorithmDetails = "Extracted 5-digit numeric PIN at offset 0x%04X".format(offset),
                        hexLines = hexLines
                    )
                }

                // Check reversed 5-digit numeric
                val revSlice = slice.reversedArray()
                val revAscii = bytesToAscii(revSlice)
                if (isValid5DigitPin(revAscii)) {
                    val hexLines = generateHexInspector(bytes, offset, 5)
                    return ExtractionResult(
                        status = ExtractionStatus.VALID_PIN_FOUND,
                        pin = revAscii,
                        pinLength = 5,
                        targetOffset = offset,
                        targetOffsetHex = "0x%04X".format(offset),
                        rawHex = rawHex,
                        isByteSwapped = true,
                        detectedEcu = "Fiat Bosch / Magneti Marelli (Byte-Swapped)",
                        algorithmDetails = "Extracted reversed 5-digit PIN at offset 0x%04X".format(offset),
                        hexLines = hexLines
                    )
                }
            }
        }

        // Strict: Do not guess random PIN
        return ExtractionResult(
            status = ExtractionStatus.STATUS_UNSUPPORTED_DUMP,
            errorMessage = "No valid 5-digit Fiat PIN detected at offsets 0x026F / 0x01E0.",
            hexLines = if (bytes.size >= 0x0274) generateHexInspector(bytes, 0x026F, 5) else emptyList()
        )
    }

    /**
     * Smart Auto-Detect Mode:
     * 1. Checks specific ECU offsets based on file size and calibration signatures.
     * 2. If known offsets fail, performs strict deep scan:
     *    - Scans for 5-digit Fiat numeric PINs.
     *    - Scans for 4-char Alphanumeric ASCII PINs.
     * 3. Rejects all filler patterns. If confidence is low, returns STATUS_UNSUPPORTED_DUMP.
     */
    fun autoDetect(bytes: ByteArray): ExtractionResult {
        // Priority 1: Check Sagem S2000 (0x0100)
        if (bytes.size >= 0x0104) {
            val res = extractSagemS2000(bytes)
            if (res.isSuccess || res.isVirginOrImmoOff) return res
        }

        // Priority 2: Check Siemens VDO / Crouse / CGE (0x03F0 / 0x00A0)
        if (bytes.size >= 0x03F4 || bytes.size >= 0x00A4) {
            val res = extractSiemensVdoCrouse(bytes)
            if (res.isSuccess || res.isVirginOrImmoOff) return res
        }

        // Priority 3: Check Valeo J34P (0x00A0 / 0x0320)
        if (bytes.size >= 0x0324) {
            val res = extractValeoJ34P(bytes)
            if (res.isSuccess || res.isVirginOrImmoOff) return res
        }

        // Priority 4: Check Peugeot BSI (0x0040 / 0x02E0)
        if (bytes.size >= 0x02E4) {
            val res = extractPeugeotBsi(bytes)
            if (res.isSuccess || res.isVirginOrImmoOff) return res
        }

        // Priority 5: Check Bosch M7.9.7 (0x01E0 / 0x0030)
        if (bytes.size >= 0x01E4) {
            val res = extractBoschM797ME744(bytes)
            if (res.isSuccess || res.isVirginOrImmoOff) return res
        }

        // Priority 6: Check Fiat 5-digit PIN (0x026F)
        if (bytes.size >= 0x0274) {
            val res = extractFiatMarelli(bytes)
            if (res.isSuccess || res.isVirginOrImmoOff) return res
        }

        // Priority 7: Check Delphi MT20U (0x0060)
        if (bytes.size >= 0x0064) {
            val res = extractDelphiMt20u(bytes)
            if (res.isSuccess || res.isVirginOrImmoOff) return res
        }

        // Priority 8: Deep Strict Heuristic Scan across the binary
        val candidates = mutableListOf<CandidatePin>()

        // Check for 5-digit numeric PINs first
        val maxOffset5 = bytes.size - 5
        for (i in 0x0040..maxOffset5) {
            val slice5 = bytes.copyOfRange(i, i + 5)
            val ascii5 = bytesToAscii(slice5)
            if (isValid5DigitPin(ascii5)) {
                candidates.add(
                    CandidatePin(
                        pin = ascii5,
                        offset = i,
                        offsetHex = "0x%04X".format(i),
                        rawHex = sliceToHex(slice5),
                        isReversed = false,
                        pinLength = 5
                    )
                )
            }
        }

        // Scan for 4-char alphanumeric PINs (skip early header 0x0000..0x003F)
        val maxOffset4 = bytes.size - 4
        for (i in 0x0040..maxOffset4) {
            val slice4 = bytes.copyOfRange(i, i + 4)
            val ascii4 = bytesToAscii(slice4)
            if (isValid4CharPin(ascii4)) {
                candidates.add(
                    CandidatePin(
                        pin = ascii4,
                        offset = i,
                        offsetHex = "0x%04X".format(i),
                        rawHex = sliceToHex(slice4),
                        isReversed = false,
                        pinLength = 4
                    )
                )
            } else {
                val revSlice = slice4.reversedArray()
                val revAscii = bytesToAscii(revSlice)
                if (isValid4CharPin(revAscii)) {
                    candidates.add(
                        CandidatePin(
                            pin = revAscii,
                            offset = i,
                            offsetHex = "0x%04X".format(i),
                            rawHex = sliceToHex(slice4),
                            isReversed = true,
                            pinLength = 4
                        )
                    )
                }
            }
        }

        if (candidates.isNotEmpty()) {
            val best = candidates.first()
            val hexLines = generateHexInspector(bytes, best.offset, best.pinLength)

            return ExtractionResult(
                status = ExtractionStatus.VALID_PIN_FOUND,
                pin = best.pin,
                pinLength = best.pinLength,
                targetOffset = best.offset,
                targetOffsetHex = best.offsetHex,
                rawHex = best.rawHex,
                isByteSwapped = best.isReversed,
                detectedEcu = "Smart Heuristic Scan (${best.pinLength}-Digit Candidate)",
                algorithmDetails = "Identified high-confidence PIN at offset ${best.offsetHex}",
                hexLines = hexLines,
                alternativeCandidates = candidates.drop(1).take(5)
            )
        }

        // STRICT: Do not guess random PINs
        return ExtractionResult(
            status = ExtractionStatus.STATUS_UNSUPPORTED_DUMP,
            errorMessage = "UNSUPPORTED_OR_CORRUPT_DUMP: No valid Immobilizer PIN pattern found in this binary file.",
            hexLines = generateHexInspector(bytes, 0, 4)
        )
    }

    /**
     * Checks multiple offsets for 4-character PIN or Virgin/Immo-Off status.
     */
    private fun checkOffsets4Char(
        bytes: ByteArray,
        offsets: List<Int>,
        ecuName: String,
        allowByteSwap: Boolean
    ): ExtractionResult {
        for (offset in offsets) {
            if (offset + 4 <= bytes.size) {
                val slice = bytes.copyOfRange(offset, offset + 4)

                // 1. Virgin / Immo-Off check
                if (isVirginOrImmoOffBytes(slice)) {
                    val hexLines = generateHexInspector(bytes, offset, 4)
                    return ExtractionResult(
                        status = ExtractionStatus.STATUS_VIRGIN_OR_IMMO_OFF,
                        pinLength = 4,
                        targetOffset = offset,
                        targetOffsetHex = "0x%04X".format(offset),
                        rawHex = sliceToHex(slice),
                        detectedEcu = ecuName,
                        algorithmDetails = "Target offset 0x%04X has virgin/immo-off bytes (0xFF/0x00)".format(offset),
                        errorMessage = "DUMP IS VIRGIN / IMMO-OFF (NO PIN REQUIRED)",
                        hexLines = hexLines
                    )
                }

                // 2. Direct ASCII check
                val directAscii = bytesToAscii(slice)
                val rawHex = sliceToHex(slice)
                if (isValid4CharPin(directAscii)) {
                    val hexLines = generateHexInspector(bytes, offset, 4)
                    return ExtractionResult(
                        status = ExtractionStatus.VALID_PIN_FOUND,
                        pin = directAscii,
                        pinLength = 4,
                        targetOffset = offset,
                        targetOffsetHex = "0x%04X".format(offset),
                        rawHex = rawHex,
                        isByteSwapped = false,
                        detectedEcu = ecuName,
                        algorithmDetails = "Extracted valid 4-character PIN at offset 0x%04X".format(offset),
                        hexLines = hexLines
                    )
                }

                // 3. Byte-swapped (Reversed) check
                if (allowByteSwap) {
                    val revSlice = slice.reversedArray()
                    val revAscii = bytesToAscii(revSlice)
                    if (isValid4CharPin(revAscii)) {
                        val hexLines = generateHexInspector(bytes, offset, 4)
                        return ExtractionResult(
                            status = ExtractionStatus.VALID_PIN_FOUND,
                            pin = revAscii,
                            pinLength = 4,
                            targetOffset = offset,
                            targetOffsetHex = "0x%04X".format(offset),
                            rawHex = rawHex,
                            isByteSwapped = true,
                            detectedEcu = "$ecuName (Byte-Swapped)",
                            algorithmDetails = "Extracted reversed byte-swap PIN at offset 0x%04X".format(offset),
                            hexLines = hexLines
                        )
                    }
                }
            }
        }

        // If specific profile offsets fail, return unsupported rather than guess
        val primaryOffset = offsets.firstOrNull() ?: 0
        return ExtractionResult(
            status = ExtractionStatus.STATUS_UNSUPPORTED_DUMP,
            errorMessage = "UNSUPPORTED_OR_CORRUPT_DUMP: No valid PIN detected at expected $ecuName offsets (${offsets.joinToString { "0x%04X".format(it) }}).",
            hexLines = if (bytes.size >= primaryOffset + 4) generateHexInspector(bytes, primaryOffset, 4) else emptyList()
        )
    }

    /**
     * Checks if a slice consists exclusively of virgin/immo-off bytes (all 0xFF, 0x00, or 0xAA).
     */
    private fun isVirginOrImmoOffBytes(slice: ByteArray): Boolean {
        if (slice.isEmpty()) return false
        val allFF = slice.all { it == 0xFF.toByte() }
        val all00 = slice.all { it == 0x00.toByte() }
        val allAA = slice.all { it == 0xAA.toByte() }
        return allFF || all00 || allAA
    }

    /**
     * Validates 4-character alphanumeric PIN:
     * - Must match [A-Z0-9]{4}
     * - Must not be in common filler list (FFFF, 0000, 9999, etc.)
     * - Must not be all identical characters (XXXX, 8888)
     */
    private fun isValid4CharPin(candidate: String): Boolean {
        if (!PIN_4CHAR_REGEX.matches(candidate)) return false
        if (FILLER_4CHAR.contains(candidate)) return false
        if (candidate.all { it == candidate[0] }) return false
        return true
    }

    /**
     * Validates 5-digit numeric PIN for Fiat:
     * - Must match [0-9]{5}
     * - Must not be filler (00000, 99999, etc.)
     * - Must not be all identical digits
     */
    private fun isValid5DigitPin(candidate: String): Boolean {
        if (!PIN_5DIGIT_REGEX.matches(candidate)) return false
        if (FILLER_5DIGIT.contains(candidate)) return false
        if (candidate.all { it == candidate[0] }) return false
        return true
    }

    private fun bytesToAscii(bytes: ByteArray): String {
        return bytes.map { b ->
            val u = b.toInt() and 0xFF
            if (u in 32..126) u.toChar() else '?'
        }.joinToString("")
    }

    private fun sliceToHex(bytes: ByteArray): String {
        return bytes.joinToString(" ") { "%02X".format(it) }
    }

    /**
     * Generates a 16-byte aligned Hex Dump inspection table around targetOffset.
     * Accurately highlights targetLength bytes (4 or 5 bytes).
     */
    fun generateHexInspector(
        bytes: ByteArray,
        targetOffset: Int,
        targetLength: Int = 4
    ): List<HexLine> {
        if (bytes.isEmpty()) return emptyList()

        val clampedOffset = targetOffset.coerceIn(0, (bytes.size - 1).coerceAtLeast(0))
        val targetRowStart = (clampedOffset / 16) * 16

        val startRow = (targetRowStart - 32).coerceAtLeast(0)
        val endRow = (targetRowStart + 48).coerceAtMost(((bytes.size + 15) / 16) * 16)

        val lines = mutableListOf<HexLine>()

        var rowAddr = startRow
        while (rowAddr < endRow && rowAddr < bytes.size) {
            val rowBytes = mutableListOf<Byte>()
            val hexStrings = mutableListOf<String>()
            val asciiChars = StringBuilder()
            val targetIndices = mutableSetOf<Int>()

            for (col in 0 until 16) {
                val byteAddr = rowAddr + col
                if (byteAddr < bytes.size) {
                    val b = bytes[byteAddr]
                    rowBytes.add(b)
                    hexStrings.add("%02X".format(b))

                    // Highlight all bytes in targetLength (4 or 5 bytes)
                    if (byteAddr in clampedOffset until (clampedOffset + targetLength)) {
                        targetIndices.add(col)
                    }

                    val unsigned = b.toInt() and 0xFF
                    if (unsigned in 32..126) {
                        asciiChars.append(unsigned.toChar())
                    } else {
                        asciiChars.append('.')
                    }
                } else {
                    hexStrings.add("  ")
                    asciiChars.append(' ')
                }
            }

            lines.add(
                HexLine(
                    offset = rowAddr,
                    offsetHex = "0x%04X".format(rowAddr),
                    bytes = rowBytes,
                    hexValues = hexStrings,
                    asciiRepresentation = asciiChars.toString(),
                    isTargetLine = targetIndices.isNotEmpty(),
                    targetByteIndices = targetIndices
                )
            )

            rowAddr += 16
        }

        return lines
    }

    // --- Sample Generators for Test / Discovery ---

    fun createSampleSagemS2000Dump(): ByteArray {
        val data = ByteArray(1024) { 0xFF.toByte() }
        val header = "SAGEM S2000 PSA 21646271-8".toByteArray(Charsets.US_ASCII)
        System.arraycopy(header, 0, data, 0x0000, header.size.coerceAtMost(32))
        val vin = "VF32AKFWF42318901".toByteArray(Charsets.US_ASCII)
        System.arraycopy(vin, 0, data, 0x0020, vin.size)

        // PIN "7K9M"
        data[0x0100] = '7'.code.toByte()
        data[0x0101] = 'K'.code.toByte()
        data[0x0102] = '9'.code.toByte()
        data[0x0103] = 'M'.code.toByte()

        data[0x0110] = '7'.code.toByte()
        data[0x0111] = 'K'.code.toByte()
        data[0x0112] = '9'.code.toByte()
        data[0x0113] = 'M'.code.toByte()
        return data
    }

    fun createSampleSiemensCrouseDump(): ByteArray {
        val data = ByteArray(2048) { 0xAA.toByte() }
        val header = "SIEMENS CROUSE CGE PSA".toByteArray(Charsets.US_ASCII)
        System.arraycopy(header, 0, data, 0x0000, header.size.coerceAtMost(32))

        // PIN "9P3B" at 0x03F0
        data[0x03F0] = '9'.code.toByte()
        data[0x03F1] = 'P'.code.toByte()
        data[0x03F2] = '3'.code.toByte()
        data[0x03F3] = 'B'.code.toByte()
        return data
    }

    fun createSampleValeoJ34PDump(): ByteArray {
        val data = ByteArray(2048) { 0xFF.toByte() }
        val header = "VALEO J34P PL4 CEM0".toByteArray(Charsets.US_ASCII)
        System.arraycopy(header, 0, data, 0x0000, header.size.coerceAtMost(32))

        // PIN "W2N8" at 0x00A0
        data[0x00A0] = 'W'.code.toByte()
        data[0x00A1] = '2'.code.toByte()
        data[0x00A2] = 'N'.code.toByte()
        data[0x00A3] = '8'.code.toByte()
        return data
    }

    fun createSampleFiatMarelliDump(): ByteArray {
        val data = ByteArray(2048) { 0x00.toByte() }
        val header = "MAGNETI MARELLI IAW 5SF".toByteArray(Charsets.US_ASCII)
        System.arraycopy(header, 0, data, 0x0000, header.size.coerceAtMost(32))

        // 5-digit PIN "49201" at 0x026F
        val pin = "49201".toByteArray(Charsets.US_ASCII)
        System.arraycopy(pin, 0, data, 0x026F, 5)
        return data
    }

    fun createSampleDelphiChineseDump(): ByteArray {
        val data = ByteArray(1024) { 0x55.toByte() }
        val header = "DELPHI MT20U CHERY MVM".toByteArray(Charsets.US_ASCII)
        System.arraycopy(header, 0, data, 0x0000, header.size.coerceAtMost(32))

        // PIN "3819" at 0x0060
        data[0x0060] = '3'.code.toByte()
        data[0x0061] = '8'.code.toByte()
        data[0x0062] = '1'.code.toByte()
        data[0x0063] = '9'.code.toByte()
        return data
    }

    fun createSampleVirginDump(): ByteArray {
        // Virgin / Immo-Off EEPROM: all 0xFF bytes
        return ByteArray(1024) { 0xFF.toByte() }
    }
}
