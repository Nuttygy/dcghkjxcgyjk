package com.ecutools.pinextractor.model

/**
 * Extraction status enum enforcing false-positive elimination and virgin/immo-off detection.
 */
enum class ExtractionStatus {
    VALID_PIN_FOUND,
    STATUS_VIRGIN_OR_IMMO_OFF,
    STATUS_UNSUPPORTED_DUMP
}

/**
 * Supported ECU types and diagnostic scan profiles.
 */
enum class EcuType(
    val displayName: String,
    val market: String,
    val chipFamily: String,
    val defaultPinLength: Int = 4
) {
    SAGEM_VALEO_S2000(
        displayName = "Sagem / Valeo S2000 (EEPROM 95080)",
        market = "Iran / Europe (PSA, IKCO)",
        chipFamily = "ST95080 (1024 bytes)",
        defaultPinLength = 4
    ),
    SIEMENS_VDO_CROUSE(
        displayName = "Siemens VDO / Crouse / CGE / SSAT (95080/95160)",
        market = "Iran / Europe (IKCO, Saipa, PSA)",
        chipFamily = "ST95080 / ST95160 (1KB - 2KB)",
        defaultPinLength = 4
    ),
    VALEO_J34P_PL4(
        displayName = "Valeo J34P / J35 / PL4 (EEPROM 95160/95320)",
        market = "Iran / Europe (Peugeot 206+ TU3A/TU5)",
        chipFamily = "ST95160 / ST95320 (2KB - 4KB)",
        defaultPinLength = 4
    ),
    BOSCH_M797_ME744(
        displayName = "Bosch M7.9.7 / ME7.4.4 / ME7.4.5 (95080/95160)",
        market = "Iran (Pride, Samand, 206) / Europe",
        chipFamily = "ST95080 / ST95160",
        defaultPinLength = 4
    ),
    BOSCH_ME17971(
        displayName = "Bosch ME17.9.71 (TU5 / EF7 Tricore)",
        market = "Iran (206, 207, Dena, Pars, Runna)",
        chipFamily = "TC1724 / TC1767 EEPROM Emulation",
        defaultPinLength = 4
    ),
    PEUGEOT_206_207_BSI(
        displayName = "Peugeot 206 / 207 BSI (Johnson/Valeo/Siemens)",
        market = "Europe / Iran (BSI Body Module)",
        chipFamily = "ST95160 / ST95040 / NEC",
        defaultPinLength = 4
    ),
    CITROEN_XANTIA_CPH(
        displayName = "Citroen Xantia CPH (EEPROM 93C46 / 95040)",
        market = "Iran / Europe (CPH Texton Immobilizer)",
        chipFamily = "93C46 / ST95040 (128 - 512 bytes)",
        defaultPinLength = 4
    ),
    DELPHI_MT20U_MT22U(
        displayName = "Delphi MT20U / MT22U / MT38 / MT80",
        market = "Chinese (Chery, Lifan, Geely, JAC, MVM)",
        chipFamily = "24C02 / 93C66 / ST95080",
        defaultPinLength = 4
    ),
    FIAT_BOSCH_MARELLI(
        displayName = "Fiat Bosch / Magneti Marelli (5-Digit PIN)",
        market = "European / Fiat (Linea, Palio, Punto, Bravo)",
        chipFamily = "ST95080 / ST95160 (1KB - 2KB)",
        defaultPinLength = 5
    ),
    AUTO_DETECT(
        displayName = "Auto-Detect / Smart Diagnostic Scan",
        market = "Universal Heuristic Scanning",
        chipFamily = "Multi-Signature Strict Scan",
        defaultPinLength = 4
    )
}

/**
 * Represents a single line in the 16-byte hex dump inspector.
 */
data class HexLine(
    val offset: Int,
    val offsetHex: String,
    val bytes: List<Byte>,
    val hexValues: List<String>,
    val asciiRepresentation: String,
    val isTargetLine: Boolean = false,
    val targetByteIndices: Set<Int> = emptySet()
)

/**
 * Candidate PIN found during heuristic scan.
 */
data class CandidatePin(
    val pin: String,
    val offset: Int,
    val offsetHex: String,
    val rawHex: String,
    val isReversed: Boolean = false,
    val pinLength: Int = 4
)

/**
 * Result of the PIN extraction process.
 */
data class ExtractionResult(
    val status: ExtractionStatus,
    val pin: String? = null,
    val pinLength: Int = 4,
    val targetOffset: Int? = null,
    val targetOffsetHex: String? = null,
    val rawHex: String? = null,
    val isByteSwapped: Boolean = false,
    val detectedEcu: String? = null,
    val algorithmDetails: String? = null,
    val hexLines: List<HexLine> = emptyList(),
    val alternativeCandidates: List<CandidatePin> = emptyList(),
    val errorMessage: String? = null
) {
    val isSuccess: Boolean
        get() = status == ExtractionStatus.VALID_PIN_FOUND

    val isVirginOrImmoOff: Boolean
        get() = status == ExtractionStatus.STATUS_VIRGIN_OR_IMMO_OFF
}

/**
 * Information about the currently loaded binary file.
 */
data class LoadedFile(
    val name: String,
    val sizeBytes: Long,
    val bytes: ByteArray
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false
        other as LoadedFile
        return name == other.name && sizeBytes == other.sizeBytes && bytes.contentEquals(other.bytes)
    }

    override fun hashCode(): Int {
        var result = name.hashCode()
        result = 31 * result + sizeBytes.hashCode()
        result = 31 * result + bytes.contentHashCode()
        return result
    }
}
