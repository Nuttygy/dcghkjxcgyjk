# Professional Automotive ECU & Immobilizer PIN Extractor (Android)

High-accuracy, 100% offline automotive diagnostic tool for extracting Immobilizer PIN codes from EEPROM dumps (.bin / .eep).

## Market & ECU Support:
- **Iranian Market (IKCO & Saipa)**:
  - Sagem / Valeo S2000 (Peugeot 206, Samand, Pars)
  - Siemens VDO / Crouse / CGE / SSAT (Pride, Tiba, Saina, Pars, 405)
  - Valeo J34P / PL4 (Peugeot 206+ TU3A/TU5)
  - Bosch M7.9.7 (Saipa Pride) & ME17.9.71 (TU5/EF7 Tricore)
  - Citroen Xantia CPH Texton Immobilizer
- **Chinese Market (Chery, Lifan, Geely, JAC, MVM)**:
  - Delphi MT20U / MT22U / MT38 / MT80
- **European & Fiat**:
  - Fiat Bosch / Magneti Marelli (5-digit numeric PIN [0-9]{5})
  - Peugeot 206 / 207 BSI Modules

## False-Positive Elimination & Virgin State:
- Strict validation rejects "FFFF", "0000", "9999", "1111", and non-PIN noise.
- Detects Virgin / Immo-Off dumps and alerts: "DUMP IS VIRGIN / IMMO-OFF (NO PIN REQUIRED)".
