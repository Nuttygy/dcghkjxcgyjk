#!/usr/bin/env bash
set -e
echo "=========================================="
echo " Building ECU PIN Code Extractor APK"
echo "=========================================="
chmod +x ./gradlew || true
./gradlew assembleDebug
echo ""
echo "SUCCESS! APK Generated at:"
echo "app/build/outputs/apk/debug/app-debug.apk"
